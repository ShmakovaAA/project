from django.apps import AppConfig

class FileindexerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fileindexer'
    verbose_name = 'Индексатор файлов'